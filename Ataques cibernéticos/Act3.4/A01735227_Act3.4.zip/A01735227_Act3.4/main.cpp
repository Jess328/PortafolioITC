//Act 3.4 - Actividad Integral de BST (Evidencia Competencia)

//A01734879 Alejandro Armenta Arellano
//A01735227 Jesús Jiménez Aguilar
//A01735346 Daniela Berenice Hernandez de Vicente

//Fecha de creación: 29 de octubre de 2021
//Fecha de modificación: 09 de noviembre de 2021

#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

struct Node{
  double data;
  string ingreso;
  Node* izq;
  Node* der;
};

Node* crearN( double val, string lin){
  Node* nuevoN = new Node;

  // Creación del nodo
  nuevoN -> izq = NULL;
  nuevoN -> data = val;
  nuevoN -> ingreso = lin;
  nuevoN -> der = NULL;

  return nuevoN;
}

void insertaN(Node* &ArbolBST, double val, string lin){
  // Caso en el que el arbol se encuentra vacio
  if(ArbolBST == NULL){
    Node* nuevoN = crearN(val, lin);
    ArbolBST = nuevoN;
  }
  //Caso en el que el árbol tenga uno o más Nodos
  else{
    double Root = ArbolBST -> data;
    if(val == Root){
      return;
    }
    else {
      if(val < Root){
        insertaN(ArbolBST -> izq, val, lin);
      }
      else{
        insertaN(ArbolBST -> der, val, lin);
      }
    }
  }
}

double separarIP(string ip){
  double IpV[5];
  double direccion = 0;
  int i = 0;
  string pal = "";
  for(auto lin: ip){
        if(lin == ' '){
            IpV[i] = (stod(pal));
            break;
        }
        if(lin == '.' || lin == ':'){
            IpV[i] = (stod(pal));
            pal = "";
            i++;
        }
        else{
            pal = pal + lin;
        }
  }

  direccion = IpV[0] + (IpV[1] * (0.01)) + (IpV[2] * (0.00001)) + (IpV[3] * (0.0000001)) + (IpV[4] * (0.00000000001));

  return direccion;
}

void inOrder(Node* ArbolBST, int &cont){
  if(ArbolBST != NULL){
    inOrder(ArbolBST -> der, cont);
    cont++;
    if(cont<=5)
      cout<< ArbolBST -> ingreso << endl;
    inOrder(ArbolBST -> izq, cont);
  }
  else{
    return;
  }
}

int main(){
  ifstream datos;
  Node* ArbolBST = NULL;
  int cont = 0;
  string line, ip, ingreso;
  datos.open("bitacora.txt");

  while(!datos.eof()){
    getline(datos, line);
    ip = line.substr(16);
    ingreso = line.substr(0, line.length());
    insertaN(ArbolBST, separarIP(ip), ingreso);
  }

  inOrder(ArbolBST, cont);

  return 0;
} 
