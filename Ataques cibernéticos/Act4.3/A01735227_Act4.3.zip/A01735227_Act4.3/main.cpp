//Act 4.3 - Actividad Integral de Grafos (Evidencia Competencia)

//A01734879 Alejandro Armenta Arellano
//A01735227 Jesús Jiménez Aguilar
//A01735346 Daniela Berenice Hernandez de Vicente

//Fecha de creación: 18 de noviembre de 2021
//Fecha de modificación: 24 de noviembre de 2021

#include <algorithm>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

struct NData{
  string data;
  NData *nextData;
};

struct NHost{
  string data;
  NHost *nextHost;
  NData *headData;
};

struct NRed{
  string data;
  NRed *nextRed;
  NHost *headHost;
};

// Función que separa red y host
// Complejidad: O(n)
string parIP(string ip, char z, int &star){
  string space = "";
  while(ip[star] != z){
    space += ip[star];
    star++;
  }
  star++;
  return space;
}

// Funcioón comparativa del grado
// Complejidad: O(1)
bool compi(pair<string, int> &x, pair<string, int> &y){
    return x.second < y.second;
}

// Función que consigue la red de mayor grado
// Complejidad: O(n^3)
void mayGra(NRed *h){
  int contR = 0, contH = 0;
  vector<pair<string, int>> mayR;
  vector<pair<string, int>> mayH;
  NRed *spaceR = h;
  while(spaceR != NULL){
    NHost *spaceH = spaceR -> headHost;
    while(spaceH != NULL){
      NData *spaceD = spaceH -> headData;
      while(spaceD != NULL){
        spaceD = spaceD -> nextData;
        contH++;
      }
      mayH.push_back({spaceR -> data + "." + spaceH -> data, contH});
      spaceH = spaceH -> nextHost;
      contH = 0;
      contR++;
    }
    mayR.push_back({spaceR -> data, contR});
    spaceR = spaceR -> nextRed;
    contR = 0;
  }
  sort(mayR.begin(), mayR.end(), compi);
  sort(mayH.begin(), mayH.end(), compi);
  int repRed = mayR.back().second;
  int repHost = mayH.back().second;
  while(mayR.size() > 0 && mayR.back().second == repRed){
    cout << mayR.back().first << endl;
    mayR.pop_back();
  }
  cout << endl;
  while(mayH.size() > 0 && mayH.back().second == repHost){
    cout << mayH.back().first << endl;
    mayH.pop_back();
  }
}

//Función que inserta nodo general
// - Complejidad: O(n)
void iData(NData * &a, string data) {
  NData *newNode = new NData;
  newNode -> data = data;
  newNode -> nextData = NULL;
  if(a == NULL){
    a = newNode;
  }
  else{
    struct NData *spaceD = a;
    while((spaceD -> nextData) != NULL){
      spaceD = spaceD -> nextData;
    }
    spaceD -> nextData = newNode;
  }
}

// Función que inserta un nodo
// Complejidad: O(n)
void iNodo(NHost * &a, string host, string data){
  NHost *newNode = new NHost;
  NHost *spaceBus = NULL;
  newNode -> data = host;
  newNode -> nextHost = NULL;
  newNode -> headData = NULL;
  if(a == NULL){
    a = newNode;
    spaceBus = a;
  }
  else{
    struct NHost *spaceH = a;
    bool ban = 1;
    while(spaceH -> data != host){
      if((spaceH -> nextHost) == NULL){
        ban = 0;
        break;
      }
      spaceH = spaceH -> nextHost;
    }
    if(!ban){
      spaceH -> nextHost = newNode;
      spaceBus = spaceH -> nextHost;
    }
    else{
      spaceBus = spaceH;
    }
  }
  iData((spaceBus -> headData), data);
}

// Función que agrega nodos en red
// - Complejidad: O(n)
void iRed(NRed * &a, string red, string host, string data){
  NRed *newNode = new NRed;
  NRed *spaceBus = NULL;
  newNode -> data = red;
  newNode -> nextRed = NULL;
  newNode -> headHost = NULL;
  if(a == NULL){
    a = newNode;
    spaceBus = a;
  }
  else{
    struct NRed *spaceR = a;
    bool ban = 1;
    while(spaceR -> data != red){
      if((spaceR -> nextRed) == NULL){
        ban = 0;
        break;
      }
      spaceR = spaceR -> nextRed;
    }
    if(!ban){
      spaceR -> nextRed = newNode;
      spaceBus = spaceR -> nextRed;
    }
    else{
      spaceBus = spaceR;
    }
  }
  iNodo((spaceBus -> headHost), host, data);
}

int main(){
  ifstream esc("bitacora2.txt");
  NRed *head = NULL;
  while(!esc.eof()){
    string mes, dia, fecha, horario, ip, mensaje;
		while(esc >> mes >> dia >> horario >> ip){
			if(esc.peek() == ' '){
				esc.get();
			}
      fecha = mes + " " + dia + " " + horario;
      int star = 0;
      string cifraR, cifraH, c2IP, c1IP, c3IP, c4IP, pue, cDa;
      ip = ip + " ";
      c1IP = parIP(ip, '.', star);
      c2IP = parIP(ip, '.', star);
      c3IP = parIP(ip, '.', star);
      c4IP = parIP(ip, ':', star);
      pue = parIP(ip, ' ', star);
      getline(esc, mensaje);
      cifraR = c1IP + "." + c2IP;
      cifraH = c3IP + "." + c4IP;
      cDa = pue + " " + mes + " " + dia + " " + horario + " " + mensaje;
      iRed(head, cifraR, cifraH, cDa);
    }
  }
  if(head != NULL){
    mayGra(head);
  }
  else{
    cout << "\n";
  }
  return 0;
}
