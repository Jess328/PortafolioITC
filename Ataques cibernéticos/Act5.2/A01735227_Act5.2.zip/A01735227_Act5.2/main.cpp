//Act 5.2 - Actividad Integral sobre el uso de códigos hash (Evidencia Competencia)

//A01734879 Alejandro Armenta Arellano
//A01735227 Jesús Jiménez Aguilar
//A01735346 Daniela Berenice Hernandez de Vicente

//Fecha de creación: 24 de noviembre de 2021
//Fecha de modificación: 30 de noviembre de 2021

#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <math.h>
#include <string>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

ifstream in("bitacora2.txt");
vector<string> res;

struct uber {
    string dom;
    int ass;
    int uni;
    bool ate = true;
    vector<string> IP;
};

vector<uber> table;

int haash(string key){
    int tot = 0;
    for (int i = 0; i < key.length(); i++){
        tot += (int)key[i];
    }
    return tot % 32749;
}

int lim(string og){
    int tot = 0;
    for (int i = 0; i < og.length(); i++){
        tot += (int)(og[i] - '0') * (pow(10, og.length()-i-1));
    }
    return tot;
}

void rifa(int num){
    string imax1;
    string imax2;
    string imax3;
    string jmax1;
    string jmax2;
    string jmax3;
    for (int i = 0; i < table[num].IP.size(); i++){
        for (int j = 0; j < table[num].IP.size(); j++){
            stringstream itp(table[num].IP[i]);
            getline(itp, imax1, '.');
            getline(itp, imax1, '.');
            getline(itp, imax1, '.');
            getline(itp, imax2, ':');
            getline(itp, imax3);
            stringstream jtp(table[num].IP[j]);
            getline(jtp, jmax1, '.');
            getline(jtp, jmax1, '.');
            getline(jtp, jmax1, '.');
            getline(jtp, jmax2, ':');
            getline(jtp, jmax3);
            if (lim(imax1) < lim(jmax1)){
                string n1 = table[num].IP[i];
                table[num].IP[i] = table[num].IP[j];
                table[num].IP[j] = n1;
            }
            else if (lim(imax1) == lim(jmax1)){
                if (lim(imax2) < lim(jmax2)){
                    string n1 = table[num].IP[i];
                    table[num].IP[i] = table[num].IP[j];
                    table[num].IP[j] = n1;
                }
                else if (lim(imax2) == lim(jmax2)){
                    if (lim(imax3) < lim(jmax3)){
                        string n1 = table[num].IP[i];
                        table[num].IP[i] = table[num].IP[j];
                        table[num].IP[j] = n1;
                    }
                }
            }
        }
    }
}

void ReadFile(){
    string lin;
    //Inicializamos un contador un 0 para contar las líneas de nuestro documento bitacora.txt
    int cont = 0;
    while(getline(in,lin)){
        res.push_back(lin);
        cont++;
    }
    string pal;
    for (int i = 0; i < res.size(); i++){
        stringstream tp(res[i]);
        getline(tp, pal, ' ');
        getline(tp, pal, ' ');
        getline(tp, pal, ':');
        getline(tp, pal, ':');
        getline(tp, pal, ' ');
        getline(tp, pal, '.');
        string n1 = to_string(lim(pal));
        getline(tp, pal, '.');
        string n2 = to_string(lim(pal));
        getline(tp, pal, ' ');
        string tip = pal;
        string mez = n1 + "." + n2;
        int agua = haash(mez);
        if (!table[agua].ate){
            if (table[agua].dom == mez){
                table[agua].ass++;
                bool c = true;
                for (int a = 0; a < table[agua].IP.size(); a++){
                    if (table[agua].IP[a] == tip){
                        c = false;
                    }
                }
                if (c){
                    table[agua].IP.push_back(mez + "." + tip);
                    table[agua].uni++;
                    rifa(agua);
                }
            }
            else {
                int y = 1;
                while (!table[(agua + y) % 32749].ate){
                    if ((agua + y) % 32749 == agua){
                        cout << "Tabla llena, imposible meter más datos" << endl;
                        break;
                    }
                    if (table[(agua + y) % 32749].dom == mez){
                        table[agua + y].ass++;
                        bool c = true;
                        for (int z = 0; z < table[(agua + y) % 32749].IP.size(); z++){
                            if (table[(agua + y) % 32749].IP[z] == tip){
                                c = false;
                            }
                        }
                        if (c){
                            table[(agua + y) % 32749].IP.push_back(mez + "." + tip);
                            table[(agua + y) % 32749].uni++;
                            rifa((agua + y) % 32749);
                            break;
                        }
                    }
                    y++;
                }
                if (table[(agua + y) % 32749].ate){
                    table[(agua + y) % 32749].dom = mez;
                    table[(agua + y) % 32749].ass = 1;
                    table[(agua + y) % 32749].uni = 1;
                    table[(agua + y) % 32749].ate = false;
                    table[(agua + y) % 32749].IP.push_back(mez + "." + tip);
                }
            }
        }
        else{
            table[agua].dom = mez;
            table[agua].ass = 1;
            table[agua].uni = 1;
            table[agua].ate = false;
            table[agua].IP.push_back(mez + "." + tip);
        }
    }
}

void search(){
    string dom;
    cin >> dom;
    string a;
    string b;
    stringstream tp(dom);
    getline(tp, a, '.');
    getline(tp, b);
    dom = to_string(lim(a)) + "." + to_string(lim(b));
    int agua = haash(dom);
    bool encontrado = false;
    int i = 0;
    if (!table[agua].ate){
        if (table[agua].dom == dom){
            encontrado = true;
        }
        else{
            while (!table[(agua + i) % 32749].ate){
                if (table[(agua + i) % 32749].dom == dom){
                    encontrado = true;
                    break;
                }
                i++;
            }
        }
    }
    if (encontrado){
        cout << table[(agua + i) % 32749].dom << endl;
        cout << table[(agua + i) % 32749].ass << endl;
        cout << table[(agua + i) % 32749].uni << endl;
        for (int x = 0; x < table[(agua + i) % 32749].IP.size(); x++){
            cout << table[(agua + i) % 32749].IP[x] << endl;
        }
    }
    else{
        cout << "Dato no encontrado" << endl;
    }
    cout << endl;
}

int main(){
    table.resize(32749);
    ReadFile();
    int num;
    cin >> num;
    for (int i = 0; i < num; i++){
        search();
    }
    return 0;
}
